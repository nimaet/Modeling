"""Phase/actuation optimizers for piezo patch optimization."""

from __future__ import annotations

import itertools
from typing import Any, Dict, Optional

import numpy as np
from scipy.optimize import minimize

try:  # package import
    from .metrics import (
        canonical_output_name,
        default_traveling_wave_settings,
        evaluate_output_metric,
        response_summary,
        tip_reduced_index,
        traveling_wave_metrics,
    )
except Exception:  # local / notebook fallback
    from metrics import (
        canonical_output_name,
        default_traveling_wave_settings,
        evaluate_output_metric,
        response_summary,
        tip_reduced_index,
        traveling_wave_metrics,
    )


def _score_response(fe, u_red: np.ndarray, output: str, settings: Optional[Dict[str, Any]]):
    if output == "traveling_wave":
        metrics = traveling_wave_metrics(fe, u_red, default_traveling_wave_settings(settings))
        return float(metrics["score"]), response_summary(fe, u_red, "rms"), metrics
    return float(evaluate_output_metric(fe, u_red, output)), response_summary(fe, u_red, output), None


def _phase_record(fe, U_cols, voltage_vector, output, settings=None, *, signs=None, label=None) -> dict:
    u_red = U_cols @ voltage_vector
    phase_rad = np.mod(np.angle(voltage_vector), 2 * np.pi)
    rel_phase = np.mod(phase_rad - phase_rad[0], 2 * np.pi)
    score, response_metrics, tw_metrics = _score_response(fe, u_red, output, settings)
    record = {
        "signs": signs,
        "phase_rad": phase_rad,
        "phase_deg": np.rad2deg(phase_rad),
        "relative_phase_rad": rel_phase,
        "relative_phase_deg": np.rad2deg(rel_phase),
        "voltage_vector": voltage_vector,
        "response": u_red[tip_reduced_index(fe)],
        "response_red": u_red,
        "score": score,
        "response_metrics": response_metrics,
    }
    if label is not None:
        record["label"] = label
    if tw_metrics is not None:
        record["traveling_wave_metrics"] = tw_metrics
    return record


def optimize_binary_phases(
    fe,
    U_cols: np.ndarray,
    output: str,
    voltage_amplitude: float = 1.0,
    *,
    settings: Optional[Dict[str, Any]] = None,
) -> dict:
    """Brute-force all binary patch signs for normal or traveling-wave scores."""
    U_cols = np.asarray(U_cols, dtype=complex)
    output = "traveling_wave" if output == "traveling_wave" else canonical_output_name(output)
    best_record = None
    all_results = []

    for signs_tuple in itertools.product([-1.0, 1.0], repeat=U_cols.shape[1]):
        signs = np.asarray(signs_tuple, dtype=float)
        record = _phase_record(
            fe,
            U_cols,
            voltage_amplitude * signs.astype(complex),
            output,
            settings,
            signs=signs,
            label="".join("+" if s > 0 else "-" for s in signs),
        )
        all_results.append(record)
        if best_record is None or record["score"] > best_record["score"]:
            best_record = record

    if best_record is None:
        raise RuntimeError("No binary phase candidates were evaluated")

    result = {
        "phase_mode": "binary",
        "phase_optimizer": "brute_force_binary_traveling_wave" if output == "traveling_wave" else "brute_force_binary",
        "all_phase_results": all_results,
        **{k: best_record[k] for k in (
            "score",
            "response",
            "response_red",
            "response_metrics",
            "signs",
            "phase_rad",
            "phase_deg",
            "relative_phase_rad",
            "relative_phase_deg",
            "voltage_vector",
        )},
    }
    if output == "traveling_wave":
        result["traveling_wave_metrics"] = best_record["traveling_wave_metrics"]
    return result


def optimize_continuous_phases(
    fe,
    U_cols: np.ndarray,
    output: str,
    voltage_amplitude: float = 1.0,
    *,
    settings: Optional[Dict[str, Any]] = None,
    n_starts: int = 8,
    seed: Optional[int] = 1,
    method: str = "L-BFGS-B",
) -> dict:
    """Optimize continuous patch phases for normal or traveling-wave scores."""
    U_cols = np.asarray(U_cols, dtype=complex)
    output = "traveling_wave" if output == "traveling_wave" else canonical_output_name(output)
    n = U_cols.shape[1]

    if output == "tip":
        phase_rad = -np.angle(U_cols[tip_reduced_index(fe), :])
        phase_rad = np.mod(phase_rad - phase_rad[0], 2 * np.pi)
        optimizer_name = "analytic_tip_alignment"
        opt_metadata = {}
    elif n == 1:
        phase_rad = np.array([0.0])
        optimizer_name = "single_patch_traveling_wave" if output == "traveling_wave" else "single_patch"
        opt_metadata = {}
    else:
        rng = np.random.default_rng(seed)

        def make_voltage(alpha_free: np.ndarray) -> np.ndarray:
            return voltage_amplitude * np.exp(1j * np.concatenate([[0.0], np.asarray(alpha_free, dtype=float)]))

        def neg_score(alpha_free: np.ndarray) -> float:
            return -_score_response(fe, U_cols @ make_voltage(alpha_free), output, settings)[0]

        starts = [np.zeros(n - 1)]
        for signs_tuple in itertools.product([0.0, np.pi], repeat=n - 1):
            starts.append(np.asarray(signs_tuple, dtype=float))
            if len(starts) >= max(2, min(n_starts, 2 ** (n - 1) + 1)):
                break
        if output == "traveling_wave":
            if len(starts) < n_starts:
                starts.append(np.linspace(0.0, np.pi, n, endpoint=False)[1:])
            if len(starts) < n_starts:
                starts.append(np.linspace(0.0, -np.pi, n, endpoint=False)[1:] % (2 * np.pi))
        while len(starts) < n_starts:
            starts.append(rng.uniform(0.0, 2 * np.pi, size=n - 1))

        best_res = None
        for x0 in starts:
            res = minimize(neg_score, x0, method=method, bounds=[(0.0, 2 * np.pi)] * (n - 1))
            if best_res is None or res.fun < best_res.fun:
                best_res = res

        phase_rad = np.mod(np.concatenate([[0.0], best_res.x]), 2 * np.pi)
        suffix = "_traveling_wave" if output == "traveling_wave" else ""
        optimizer_name = f"numeric_{method}{suffix}"
        success = bool(getattr(best_res, "success", False))
        message = str(getattr(best_res, "message", ""))
        opt_metadata = {
            "inner_opt_result": best_res,
            "inner_opt_success": success,
            "inner_opt_message": message,
            "inner_opt_warning": None if success else f"{optimizer_name} did not report success: {message}",
        }

    record = _phase_record(fe, U_cols, voltage_amplitude * np.exp(1j * phase_rad), output, settings)
    result = {
        "phase_mode": "continuous",
        "phase_optimizer": optimizer_name,
        "all_phase_results": None,
        **record,
        **opt_metadata,
    }
    return result
