"""Patch-placement optimizer for 1D piezoelectric beam FE models.

Version 3 / multimode refactor
-----------------------------
This module keeps notebooks thin: configure settings, call
``PiezoPatchOptimizer.run()``, then plot/post-process results.

Supported objective kinds
- ``single_mode``: optimize one selected natural frequency/mode.
- ``multi_mode``: optimize a weighted aggregate of several modes. By default,
  each mode gets its own best phase vector for the same geometry. This answers:
  "Can one geometry actuate several target modes well if I can retune phase per
  mode?"
- ``traveling_wave``: optimize a harmonic response for traveling-wave quality
  using a Feeny-style traveling index, bounded RMS amplitude reward, and
  envelope-uniformity reward.

Supported output metrics
- ``tip``: tip displacement magnitude.
- ``mean_abs`` / ``line_average``: line-average of |w(x)|.
- ``rms``: RMS of |w(x)|.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import OptimizeResult, differential_evolution, minimize
from tqdm.auto import tqdm

try:  # package imports
    from Modeling.models_fish.beam_properties import PiezoBeamParams
    import Modeling.models_fish.model as FE_module
except Exception:  # local / notebook fallback
    from beam_properties import PiezoBeamParams
    import model as FE_module


# -----------------------------------------------------------------------------
# Settings
# -----------------------------------------------------------------------------

@dataclass
class GeometrySettings:
    """Outer geometry design settings.

    The design vector is always
    ``z = [L1, g12, L2, g23, ..., g(n-1,n), Ln]`` and has length ``2*Np - 1``.
    The final substrate length is the remaining beam length.
    """

    Np: int = 3
    patch_length_bounds: Tuple[float, float] = (10e-3, 40e-3)
    gap_bounds: Tuple[float, float] = (4e-3, 80e-3)
    tip_substrate_bounds: Tuple[float, Optional[float]] = (0.0, 150e-3)
    total_patch_length_bounds: Optional[Tuple[float, float]] = None
    fixed_patch_lengths: Dict[int, float] = field(default_factory=dict)  # patch index j = 0..Np-1
    fixed_gaps: Dict[int, float] = field(default_factory=dict)           # gap index j = 0..Np-2
    invalid_penalty: float = 1e12


@dataclass
class ObjectiveSettings:
    """Objective and inner phase-optimization settings.

    Parameters
    ----------
    objective:
        ``"single_mode"``, ``"multi_mode"``, or ``"traveling_wave"``.
    target_mode_number:
        Backward-compatible alias for ``single_mode_number``. If supplied, it
        overrides ``single_mode_number``.
    single_mode_number:
        Mode number used for ``objective="single_mode"``. Uses 1-based indexing.
    multi_mode_numbers:
        Mode numbers used for ``objective="multi_mode"``. Uses 1-based indexing.
    multi_mode_weights:
        Optional per-mode weights. If omitted, all modes get equal weight.
    multi_mode_score_normalizers:
        Optional per-mode positive normalizers. Useful when one mode naturally
        has a much larger response. If omitted, no normalization is applied.
    multi_mode_reduction:
        ``"weighted_sum"``/``"sum"``, ``"weighted_mean"``/``"mean"``,
        ``"min"``, or ``"geometric_mean"``.
    multi_mode_phase_policy:
        Currently only ``"per_mode"`` is implemented. This optimizes phase
        independently for each mode while sharing the same geometry.
    """

    objective: str = "single_mode"

    # Backward-compatible alias used by earlier notebooks/runners.
    target_mode_number: Optional[int] = None
    single_mode_number: int = 1
    multi_mode_numbers: Sequence[int] = field(default_factory=lambda: (1, 2, 3))
    multi_mode_weights: Optional[Sequence[float]] = None
    multi_mode_score_normalizers: Optional[Sequence[float]] = None
    multi_mode_reduction: str = "weighted_sum"
    multi_mode_phase_policy: str = "per_mode"

    # Traveling-wave objective settings. Common keys:
    #   frequency_hz: explicit excitation frequency.
    #   mode_pair: two 1-based modes; used with frequency_fraction if no
    #       frequency_hz is supplied.
    #   frequency_fraction: interpolation between mode_pair frequencies.
    #   amplitude_reference: A_ref in A_rms / (A_ref + A_rms). If None or <= 0,
    #       the amplitude term is disabled.
    #   x_fraction_bounds: spatial window used for wave-quality metrics.
    #   direction: "either", "positive_x"/"tailward", or "negative_x"/"headward".
    traveling_wave_settings: Dict[str, Any] = field(default_factory=dict)

    voltage_amplitude: float = 1.0
    phase_mode: str = "binary"  # "binary" or "continuous"

    # Output metric used in the objective.
    #   "tip" / "tip_disp": tip displacement magnitude.
    #   "mean_abs" / "line_average": integral average of |w(x)| over beam length.
    #   "rms" / "rms_displacement": RMS of |w(x)| over beam length.
    output: str = "tip"

    # Dense final sweep settings for post-processing.
    final_sweep_range_hz: Tuple[float, float] = (0.1, 10.0)
    final_sweep_n_freq: int = 1000

    # Only used when phase_mode="continuous" and output is not scalar tip.
    # For tip output, continuous phase has an analytic solution.
    continuous_phase_n_starts: int = 8
    continuous_phase_seed: Optional[int] = 1
    continuous_phase_method: str = "L-BFGS-B"

    def __post_init__(self):
        if self.target_mode_number is not None:
            self.single_mode_number = int(self.target_mode_number)

        self.objective = canonical_objective_name(self.objective)
        self.phase_mode = self.phase_mode.lower().strip()
        self.output = canonical_output_name(self.output)

        self.single_mode_number = int(self.single_mode_number)
        self.multi_mode_numbers = tuple(int(m) for m in self.multi_mode_numbers)

        if self.multi_mode_weights is not None:
            self.multi_mode_weights = tuple(float(w) for w in self.multi_mode_weights)
            if len(self.multi_mode_weights) != len(self.multi_mode_numbers):
                raise ValueError("multi_mode_weights must have the same length as multi_mode_numbers")

        if self.multi_mode_score_normalizers is not None:
            self.multi_mode_score_normalizers = tuple(float(v) for v in self.multi_mode_score_normalizers)
            if len(self.multi_mode_score_normalizers) != len(self.multi_mode_numbers):
                raise ValueError("multi_mode_score_normalizers must have the same length as multi_mode_numbers")
            if np.any(np.asarray(self.multi_mode_score_normalizers) <= 0):
                raise ValueError("multi_mode_score_normalizers must be positive")

        if self.multi_mode_phase_policy.lower().strip() != "per_mode":
            raise NotImplementedError("Only multi_mode_phase_policy='per_mode' is implemented for now")


@dataclass
class OptimizerSettings:
    method: str = "differential_evolution"  # differential_evolution, random, powell, random_powell
    maxiter: int = 15
    popsize: int = 8
    seed: Optional[int] = 1
    polish: bool = False
    # Integer per scipy, or a map-like callable such as ThreadPool.map.
    workers: Any = 1
    n_random_samples: int = 300
    powell_maxiter: int = 80
    powell_xtol: float = 1e-4
    powell_ftol: float = 1e-4
    show_progress: bool = True
    raise_exceptions: bool = False
    raise_optimizer_failures: bool = False


# -----------------------------------------------------------------------------
# Basic helpers
# -----------------------------------------------------------------------------

def canonical_objective_name(objective: str) -> str:
    name = objective.lower().strip().replace("-", "_")
    aliases = {
        "single": "single_mode",
        "single_mode": "single_mode",
        "mode": "single_mode",
        "multi": "multi_mode",
        "multimode": "multi_mode",
        "multi_mode": "multi_mode",
        "traveling": "traveling_wave",
        "travelling": "traveling_wave",
        "traveling_wave": "traveling_wave",
        "travelling_wave": "traveling_wave",
    }
    if name not in aliases:
        raise ValueError("objective must be 'single_mode', 'multi_mode', or 'traveling_wave'")
    return aliases[name]


def make_region_sequence(n_patches: int) -> List[str]:
    """Return ['piezo','substrate', ...] for N patch/substrate pairs."""
    if n_patches < 1:
        raise ValueError("n_patches must be at least 1")
    seq: List[str] = []
    for _ in range(int(n_patches)):
        seq.extend(["piezo", "substrate"])
    return seq


# -----------------------------------------------------------------------------
# Output and traveling-wave metrics
# -----------------------------------------------------------------------------

try:  # package imports
    from Modeling.models_fish.metrics import (
        canonical_output_name,
    )
except Exception:  # local / notebook fallback
    from metrics import (
        canonical_output_name,
    )


try:  # package imports
    from Modeling.models_fish.objectives import (
        ModeResponseObjective,
        MultiModeObjective,
        TravelingWaveObjective,
    )
except Exception:  # local / notebook fallback
    from objectives import (
        ModeResponseObjective,
        MultiModeObjective,
        TravelingWaveObjective,
    )

def _copy_array_or_value(value):
    if isinstance(value, np.ndarray):
        return value.copy()
    if isinstance(value, list):
        return [_copy_array_or_value(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_copy_array_or_value(v) for v in value)
    if isinstance(value, dict):
        return {k: _copy_array_or_value(v) for k, v in value.items()}
    return value


# -----------------------------------------------------------------------------
# Main optimizer
# -----------------------------------------------------------------------------

class PiezoPatchOptimizer:
    """Outer geometry optimizer with an inner phase optimization layer."""

    def __init__(
        self,
        L: float,
        region_types: dict,
        base_params: PiezoBeamParams,
        geometry_settings: GeometrySettings,
        objective_settings: Optional[ObjectiveSettings] = None,
        optimizer_settings: Optional[OptimizerSettings] = None,
        *,
        fe_module=FE_module,
        default_h: float = 1e-3,
    ):
        if objective_settings is None:
            objective_settings = ObjectiveSettings()

        self.L = float(L)
        self.region_types = region_types
        self.base_params = base_params
        self.geometry_settings = geometry_settings
        self.objective_settings = objective_settings
        self.optimizer_settings = optimizer_settings or OptimizerSettings()
        self.fe_module = fe_module
        self.default_h = default_h
        self.evaluation_history: list[dict] = []

    def _raise_exceptions(self) -> bool:
        return bool(getattr(self.optimizer_settings, "raise_exceptions", False))

    def _raise_optimizer_failures(self) -> bool:
        return bool(getattr(self.optimizer_settings, "raise_optimizer_failures", False))

    def objective(self, z: np.ndarray) -> float:
        fe, layout, penalty = self.build_fe_for_design(z)
        if penalty > 0 or fe is None:
            return float(penalty)

        try:
            inner = self.inner_optimizer(fe)
            score = float(inner["score"])
        except Exception as exc:
            if self._raise_exceptions():
                raise
            self.evaluation_history.append({
                "z": np.asarray(z, dtype=float).copy(),
                "layout": layout,
                "score": -np.inf,
                "error": repr(exc),
            })
            return self.geometry_settings.invalid_penalty

        self.evaluation_history.append(
            {
                "z": np.asarray(z, dtype=float).copy(),
                "layout": _copy_array_or_value(layout),
                "score": score,
                "objective": inner.get("objective"),
                "output": inner.get("output"),
                "freq_hz": _copy_array_or_value(inner.get("freq_hz")),
                "phase_mode": inner.get("phase_mode"),
                "phase_deg": _copy_array_or_value(inner.get("phase_deg")),
                "relative_phase_deg": _copy_array_or_value(inner.get("relative_phase_deg")),
                "natural_freqs": fe.freq[: min(8, len(fe.freq))].copy(),
                "response_metrics": _copy_array_or_value(inner.get("response_metrics", {})),
                "raw_mode_scores": _copy_array_or_value(inner.get("raw_mode_scores", None)),
            }
        )
        return -score

    def _finalize_scipy_result(self, result: OptimizeResult, optimizer_name: str) -> OptimizeResult:
        success = bool(getattr(result, "success", False))
        message = str(getattr(result, "message", ""))
        result.optimizer_name = optimizer_name
        result.optimization_warning = None if success else f"{optimizer_name} did not report success: {message}"
        if result.optimization_warning and self._raise_optimizer_failures():
            raise RuntimeError(result.optimization_warning)
        return result

    def best_eval_from_history(self) -> Optional[dict]:
        valid = [h for h in self.evaluation_history if np.isfinite(h.get("score", -np.inf))]
        if not valid:
            return None
        return max(valid, key=lambda h: h["score"])

    def run_random_search(self) -> OptimizeResult:
        opt = self.optimizer_settings
        bounds = np.asarray(self.make_bounds(), dtype=float)
        rng = np.random.default_rng(opt.seed)
        best_x = None
        best_fun = np.inf
        iterator = range(opt.n_random_samples)
        if opt.show_progress:
            iterator = tqdm(iterator, desc="Random search")

        for _ in iterator:
            z = rng.uniform(bounds[:, 0], bounds[:, 1])
            fixed = bounds[:, 0] == bounds[:, 1]
            z[fixed] = bounds[fixed, 0]
            f = self.objective(z)
            if f < best_fun:
                best_fun = float(f)
                best_x = z.copy()

        return self._finalize_scipy_result(
            OptimizeResult(x=best_x, fun=best_fun, success=True, message="Random search complete", nfev=opt.n_random_samples),
            "random_search",
        )

    def run_powell_refinement(self, x0=None) -> OptimizeResult:
        opt = self.optimizer_settings
        bounds = self.make_bounds()
        if x0 is None:
            x0 = np.array([(a + b) / 2 for a, b in bounds], dtype=float)
        result = minimize(
            self.objective,
            np.asarray(x0, dtype=float),
            method="Powell",
            bounds=bounds,
            options={"maxiter": opt.powell_maxiter, "xtol": opt.powell_xtol, "ftol": opt.powell_ftol, "disp": opt.show_progress},
        )
        return self._finalize_scipy_result(result, "powell")

    def run_differential_evolution(self) -> OptimizeResult:
        opt = self.optimizer_settings
        result = differential_evolution(
            self.objective,
            bounds=self.make_bounds(),
            maxiter=opt.maxiter,
            popsize=opt.popsize,
            seed=opt.seed,
            polish=opt.polish,
            workers=opt.workers,
            updating="deferred" if opt.workers != 1 else "immediate",
            disp=opt.show_progress,
        )
        return self._finalize_scipy_result(result, "differential_evolution")

    def run(self) -> OptimizeResult:
        method = self.optimizer_settings.method.lower()
        if method in ("de", "differential_evolution"):
            return self.run_differential_evolution()
        if method == "random":
            return self.run_random_search()
        if method == "powell":
            return self.run_powell_refinement()
        if method in ("random_powell", "random+powell", "random-powell"):
            r0 = self.run_random_search()
            r1 = self.run_powell_refinement(r0.x)
            r1.random_result = r0
            return r1
        raise ValueError(f"Unknown optimizer method: {self.optimizer_settings.method}")

    def inspect_result(self, result: OptimizeResult) -> dict:
        """Rebuild and evaluate the best design from an OptimizeResult."""
        fe, layout, penalty = self.build_fe_for_design(result.x)
        if penalty > 0 or fe is None:
            raise RuntimeError("Could not rebuild FE model for optimization result")
        inner = self.inner_optimizer(fe)
        return {"result": result, "fe": fe, "layout": layout, "penalty": penalty, "inner": inner}

    @property
    def n_patches(self) -> int:
        return int(self.geometry_settings.Np)

    @property
    def n_design_variables(self) -> int:
        return 2 * self.n_patches - 1

    def make_region_sequence(self) -> List[str]:
        return make_region_sequence(self.n_patches)

    def make_bounds(self) -> List[Tuple[float, float]]:
        gs = self.geometry_settings
        bounds: List[Tuple[float, float]] = []
        for j in range(gs.Np):
            patch_bounds = gs.patch_length_bounds
            if j in gs.fixed_patch_lengths:
                v = float(gs.fixed_patch_lengths[j])
                patch_bounds = (v, v)
            bounds.append(patch_bounds)

            if j < gs.Np - 1:
                gap_bounds = gs.gap_bounds
                if j in gs.fixed_gaps:
                    v = float(gs.fixed_gaps[j])
                    gap_bounds = (v, v)
                bounds.append(gap_bounds)
        return bounds

    def decode_design(self, z: np.ndarray) -> dict:
        """Decode z into patch lengths, gaps, starts, active xL/xR, and tip length."""
        z = np.asarray(z, dtype=float)
        if z.size != self.n_design_variables:
            raise ValueError(f"Expected design vector length {self.n_design_variables}, got {z.size}")

        patch_lengths = z[0::2]
        gaps = z[1::2]
        x_starts = [0.0]
        x = 0.0
        for j in range(self.n_patches):
            x += patch_lengths[j]
            x_starts.append(x)  # start of substrate after patch j
            if j < self.n_patches - 1:
                x += gaps[j]
                x_starts.append(x)  # start of next patch

        x_starts = np.asarray(x_starts, dtype=float)
        xL = x_starts[0::2]
        xR = x_starts[1::2]
        tip_substrate = self.L - x_starts[-1]

        return {
            "z": z,
            "patch_lengths": patch_lengths,
            "gaps": gaps,
            "x_starts": x_starts,
            "xL": xL,
            "xR": xR,
            "tip_substrate": float(tip_substrate),
            "total_patch_length": float(np.sum(patch_lengths)),
            "region_sequence": self.make_region_sequence(),
        }

    def geometry_penalty(self, layout: dict) -> float:
        gs = self.geometry_settings
        penalty = 0.0

        if np.any(layout["patch_lengths"] <= 0) or np.any(layout["gaps"] < 0):
            penalty += gs.invalid_penalty
        if np.any(np.diff(layout["x_starts"]) < -1e-12):
            penalty += gs.invalid_penalty
        if layout["x_starts"][-1] > self.L + 1e-12:
            penalty += gs.invalid_penalty

        tip_min, tip_max = gs.tip_substrate_bounds
        tip_max = self.L if tip_max is None else tip_max
        tip = layout["tip_substrate"]
        if tip < tip_min:
            penalty += gs.invalid_penalty + gs.invalid_penalty * (tip_min - tip) ** 2
        if tip > tip_max:
            penalty += gs.invalid_penalty + gs.invalid_penalty * (tip - tip_max) ** 2

        if gs.total_patch_length_bounds is not None:
            low, high = gs.total_patch_length_bounds
            total = layout["total_patch_length"]
            if total < low:
                penalty += gs.invalid_penalty + gs.invalid_penalty * (low - total) ** 2
            if total > high:
                penalty += gs.invalid_penalty + gs.invalid_penalty * (total - high) ** 2

        return float(penalty)

    def build_fe_for_design(self, z: np.ndarray):
        """Return (fe, layout, penalty) for a candidate design."""
        layout = self.decode_design(z)
        penalty = self.geometry_penalty(layout)
        if penalty > 0:
            return None, layout, penalty

        try:
            geom = self.fe_module.build_geometry_from_types(
                L=self.L,
                region_types=self.region_types,
                region_sequence=layout["region_sequence"],
                x_starts=layout["x_starts"],
                default_h=self.default_h,
            )
            params = copy.deepcopy(self.base_params)
            params.geometry = geom
            if hasattr(params, "sync_patch_count"):
                params.sync_patch_count(len(geom.piezos))
            else:  # backward compatibility with older parameter class
                params.n_patches = len(geom.piezos)
                params.S = len(geom.piezos)
                params.Q = len(geom.piezos)
                params.Cp = params.Cp_scalar * np.ones(params.S)
            fe = self.fe_module.PiezoBeamFE(params)
            return fe, layout, 0.0
        except Exception as exc:
            if getattr(self.optimizer_settings, "raise_exceptions", False):
                raise
            layout["error"] = repr(exc)
            return None, layout, self.geometry_settings.invalid_penalty

    def effective_damping_matrix(self, fe) -> np.ndarray:
        if hasattr(fe, "effective_damping_matrix"):
            return fe.effective_damping_matrix()
        return fe.C_red + fe.params.c_alpha * fe.M_red + fe.params.c_beta * fe.K_red

    def response_columns(self, fe, omega: float) -> np.ndarray:
        """Return reduced displacement columns per unit patch voltage at omega."""
        D = self.effective_damping_matrix(fe)
        Z = fe.K_red + 1j * omega * D - omega**2 * fe.M_red
        return np.linalg.solve(Z, fe.Gamma_red)

    def _objective_for_settings(self):
        objective = canonical_objective_name(self.objective_settings.objective)
        if objective == "single_mode":
            return ModeResponseObjective(self)
        if objective == "multi_mode":
            return MultiModeObjective(self)
        if objective == "traveling_wave":
            return TravelingWaveObjective(self)
        raise RuntimeError(f"Unhandled objective {objective}")

    def inner_optimizer(self, fe) -> dict:
        """Evaluate the configured objective for a built FE model."""
        return self._objective_for_settings().evaluate(fe)

