"""Optional post-processing utilities for piezo patch optimization results."""

from __future__ import annotations

import copy
import itertools
from typing import Any, Dict, Optional, Sequence

import numpy as np

try:  # package imports
    from .metrics import (
        canonical_output_name,
        default_traveling_wave_settings,
        evaluate_output_metric,
        metric_label,
        tip_reduced_index,
        traveling_wave_metrics,
    )
    from .optimizer import ObjectiveSettings, PiezoPatchOptimizer, canonical_objective_name
except Exception:  # local / notebook fallback
    from metrics import (
        canonical_output_name,
        default_traveling_wave_settings,
        evaluate_output_metric,
        metric_label,
        tip_reduced_index,
        traveling_wave_metrics,
    )
    from optimizer import ObjectiveSettings, PiezoPatchOptimizer, canonical_objective_name


def get_mode_result(inner: dict, mode_number: Optional[int] = None, mode_index: int = 0) -> dict:
    """Extract one mode result from a single- or multi-mode inner result."""
    mode_results = inner.get("mode_results", [inner])
    if mode_number is not None:
        for result in mode_results:
            if int(result["mode_number"]) == int(mode_number):
                return result
        raise KeyError(f"mode_number={mode_number} not found in mode_results")
    return mode_results[int(mode_index)]


def dense_metric_frf_for_plot(
    optimizer: PiezoPatchOptimizer,
    fe,
    voltage_vector,
    *,
    output: Optional[str] = None,
    sweep_range_hz=None,
    n_freq=None,
) -> dict:
    """Dense mechanical FRF for one voltage pattern and selected output metric."""
    settings = optimizer.objective_settings
    output = canonical_output_name(output or settings.output)
    sweep_range_hz = sweep_range_hz or settings.final_sweep_range_hz
    n_freq = int(n_freq or settings.final_sweep_n_freq)
    freq = np.linspace(float(sweep_range_hz[0]), float(sweep_range_hz[1]), n_freq)
    omega_vec = 2 * np.pi * freq
    voltage_vector = np.asarray(voltage_vector, dtype=complex)
    damping = optimizer.effective_damping_matrix(fe)

    metric = np.zeros(n_freq, dtype=float)
    tip_disp = np.zeros(n_freq, dtype=float)
    mean_abs = np.zeros(n_freq, dtype=float)
    rms = np.zeros(n_freq, dtype=float)
    response_complex_tip = np.zeros(n_freq, dtype=complex)

    for k, omega in enumerate(omega_vec):
        z_dyn = fe.K_red + 1j * omega * damping - omega**2 * fe.M_red
        u_red = np.linalg.solve(z_dyn, fe.Gamma_red @ voltage_vector)
        metric[k] = evaluate_output_metric(fe, u_red, output)
        tip_disp[k] = evaluate_output_metric(fe, u_red, "tip")
        mean_abs[k] = evaluate_output_metric(fe, u_red, "mean_abs")
        rms[k] = evaluate_output_metric(fe, u_red, "rms")
        response_complex_tip[k] = u_red[tip_reduced_index(fe)]

    return {
        "freq": freq,
        "omega": omega_vec,
        "output": output,
        "metric_label": metric_label(output),
        "metric": metric,
        "tip_disp": tip_disp,
        "mean_abs": mean_abs,
        "rms": rms,
        "response_complex": response_complex_tip,
        "voltage_vector": voltage_vector,
    }


def dense_metric_frf_for_mode_result(optimizer: PiezoPatchOptimizer, fe, mode_result: dict, **kwargs) -> dict:
    """Dense FRF using the voltage vector stored in a single mode result."""
    return dense_metric_frf_for_plot(
        optimizer,
        fe,
        mode_result["voltage_vector"],
        output=mode_result.get("output"),
        **kwargs,
    )


def dense_tip_frf_for_plot(
    optimizer: PiezoPatchOptimizer,
    fe,
    voltage_vector,
    *,
    sweep_range_hz=None,
    n_freq=None,
) -> dict:
    """Dense tip FRF for one voltage pattern."""
    return dense_metric_frf_for_plot(
        optimizer,
        fe,
        voltage_vector,
        output="tip",
        sweep_range_hz=sweep_range_hz,
        n_freq=n_freq,
    )


def dense_all_binary_metric_frf_for_plot(
    optimizer: PiezoPatchOptimizer,
    fe,
    *,
    output: Optional[str] = None,
    sweep_range_hz=None,
    n_freq=None,
) -> list[dict]:
    """Dense FRFs for all binary sign patterns using the selected output metric."""
    out = []
    for signs_tuple in itertools.product([-1.0, 1.0], repeat=fe.Gamma_red.shape[1]):
        signs = np.asarray(signs_tuple, dtype=float)
        frf = dense_metric_frf_for_plot(
            optimizer,
            fe,
            optimizer.objective_settings.voltage_amplitude * signs,
            output=output or optimizer.objective_settings.output,
            sweep_range_hz=sweep_range_hz,
            n_freq=n_freq,
        )
        frf["signs"] = signs
        frf["label"] = "".join("+" if s > 0 else "-" for s in signs)
        out.append(frf)
    return out


def dense_all_binary_frf_for_plot(
    optimizer: PiezoPatchOptimizer,
    fe,
    *,
    sweep_range_hz=None,
    n_freq=None,
) -> list[dict]:
    """Dense tip FRFs for all binary sign patterns."""
    return dense_all_binary_metric_frf_for_plot(
        optimizer,
        fe,
        output="tip",
        sweep_range_hz=sweep_range_hz,
        n_freq=n_freq,
    )


def dense_traveling_wave_metrics_for_plot(
    optimizer: PiezoPatchOptimizer,
    fe,
    voltage_vector,
    *,
    sweep_range_hz=None,
    n_freq=None,
    traveling_wave_settings: Optional[Dict[str, Any]] = None,
) -> dict:
    """Dense frequency sweep of traveling-wave metrics for one voltage pattern."""
    settings = default_traveling_wave_settings(
        traveling_wave_settings or optimizer.objective_settings.traveling_wave_settings
    )
    sweep_range_hz = sweep_range_hz or optimizer.objective_settings.final_sweep_range_hz
    n_freq = int(n_freq or optimizer.objective_settings.final_sweep_n_freq)
    freq = np.linspace(float(sweep_range_hz[0]), float(sweep_range_hz[1]), n_freq)
    omega_vec = 2 * np.pi * freq
    voltage_vector = np.asarray(voltage_vector, dtype=complex)
    damping = optimizer.effective_damping_matrix(fe)

    score = np.zeros(n_freq, dtype=float)
    traveling_index = np.zeros(n_freq, dtype=float)
    amplitude_rms = np.zeros(n_freq, dtype=float)
    amplitude_score = np.zeros(n_freq, dtype=float)
    envelope_cv = np.zeros(n_freq, dtype=float)
    envelope_score = np.zeros(n_freq, dtype=float)
    phase_slope = np.zeros(n_freq, dtype=float)
    direction_score = np.zeros(n_freq, dtype=float)

    for k, omega in enumerate(omega_vec):
        z_dyn = fe.K_red + 1j * omega * damping - omega**2 * fe.M_red
        metrics = traveling_wave_metrics(fe, np.linalg.solve(z_dyn, fe.Gamma_red @ voltage_vector), settings)
        score[k] = metrics["score"]
        traveling_index[k] = metrics["traveling_index"]
        amplitude_rms[k] = metrics["amplitude_rms"]
        amplitude_score[k] = metrics["amplitude_score"]
        envelope_cv[k] = metrics["envelope_cv"]
        envelope_score[k] = metrics["envelope_score"]
        phase_slope[k] = metrics["phase_slope_rad_per_m"]
        direction_score[k] = metrics["direction_score"]

    return {
        "freq": freq,
        "omega": omega_vec,
        "score": score,
        "traveling_index": traveling_index,
        "amplitude_rms": amplitude_rms,
        "amplitude_score": amplitude_score,
        "envelope_cv": envelope_cv,
        "envelope_score": envelope_score,
        "phase_slope_rad_per_m": phase_slope,
        "direction_score": direction_score,
        "voltage_vector": voltage_vector,
        "traveling_wave_settings": settings,
        "metric_label": "Traveling-wave objective score [-]",
    }


def single_mode_calibration_optimizer(
    optimizer: PiezoPatchOptimizer,
    mode_number: int,
    *,
    optimizer_settings=None,
) -> PiezoPatchOptimizer:
    """Return a single-mode optimizer using another optimizer as a template."""
    settings_dict = copy.deepcopy(optimizer.objective_settings.__dict__)
    settings_dict.update(
        {
            "objective": "single_mode",
            "target_mode_number": None,
            "single_mode_number": int(mode_number),
            "multi_mode_weights": None,
            "multi_mode_score_normalizers": None,
        }
    )
    return PiezoPatchOptimizer(
        L=optimizer.L,
        region_types=copy.deepcopy(optimizer.region_types),
        base_params=copy.copy(optimizer.base_params),
        geometry_settings=copy.deepcopy(optimizer.geometry_settings),
        objective_settings=ObjectiveSettings(**settings_dict),
        optimizer_settings=copy.copy(optimizer_settings or optimizer.optimizer_settings),
        fe_module=optimizer.fe_module,
        default_h=optimizer.default_h,
    )


def calibrate_multimode_score_normalizers(
    optimizer: PiezoPatchOptimizer,
    modes: Optional[Sequence[int]] = None,
    *,
    optimizer_settings=None,
    normalizer_floor: Optional[float] = None,
    apply: bool = False,
    verbose: bool = True,
) -> dict:
    """Estimate multi-mode normalizers from independent single-mode optima."""
    objective_settings = optimizer.objective_settings
    if modes is None:
        if canonical_objective_name(objective_settings.objective) == "multi_mode":
            modes = objective_settings.multi_mode_numbers
        else:
            modes = (objective_settings.single_mode_number,)

    modes = tuple(int(m) for m in modes)
    if len(modes) == 0:
        raise ValueError("modes must contain at least one mode number")

    floor = None if normalizer_floor is None else float(normalizer_floor)
    if floor is not None and floor <= 0:
        raise ValueError("normalizer_floor must be positive when provided")

    records = []
    scores = []
    normalizers = []
    for mode_number in modes:
        if verbose:
            print(f"Calibrating mode {mode_number} normalizer...")
        mode_optimizer = single_mode_calibration_optimizer(
            optimizer,
            mode_number,
            optimizer_settings=optimizer_settings,
        )
        result = mode_optimizer.run()
        best = mode_optimizer.inspect_result(result)
        score = float(best["inner"]["score"])
        if not np.isfinite(score) or score <= 0:
            raise RuntimeError(f"Single-mode calibration for mode {mode_number} returned invalid score {score!r}")

        normalizer = max(score, floor) if floor is not None else score
        scores.append(score)
        normalizers.append(normalizer)
        records.append(
            {
                "mode_number": mode_number,
                "score": score,
                "normalizer": normalizer,
                "optimizer": mode_optimizer,
                "result": result,
                "best": best,
            }
        )
        if verbose:
            print(f"  best score = {score:.6e}, normalizer = {normalizer:.6e}")

    normalizers_tuple = tuple(float(v) for v in normalizers)
    if apply:
        optimizer.objective_settings.multi_mode_score_normalizers = normalizers_tuple

    return {
        "modes": modes,
        "scores": np.asarray(scores, dtype=float),
        "normalizers": np.asarray(normalizers, dtype=float),
        "records": records,
        "applied": bool(apply),
    }
